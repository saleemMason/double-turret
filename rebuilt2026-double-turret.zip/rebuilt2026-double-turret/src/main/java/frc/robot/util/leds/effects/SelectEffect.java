package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;
import java.util.Map;
import java.util.function.Supplier;

/**
 * An {@link LedEffect} that displays one of a selection of effects using a selector and a key to
 * effect mapping.
 *
 * <p>If the selector returns a value not in the effects map, uses {@link SolidColorEffect#off()}
 *
 * @param <K> The type of key used to select the effect
 */
public class SelectEffect<K> implements LedEffect {
  private static final LedEffect defaultEffect = SolidColorEffect.off();

  private final Map<K, LedEffect> effects;
  private final Supplier<? extends K> selector;

  /**
   * Creates a new {@link SelectEffect}
   *
   * @param commands the map of effects to choose from
   * @param selector the selector to determine which effect to display
   */
  public SelectEffect(Map<K, LedEffect> effects, Supplier<? extends K> selector) {
    this.effects = effects;
    this.selector = selector;
  }

  @Override
  public LedOutputFn process(LedSection section) {
    LedEffect effect = effects.getOrDefault(selector.get(), defaultEffect);
    return effect.process(section);
  }
}
