package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedColor;
import frc.robot.util.leds.LedEffect.SimpleLedEffect;

public class RainbowEffect implements SimpleLedEffect {

  @Override
  public LedColor get(double position) {
    double hue = position;

    // HSL to RGB with S = 1.0 and C = 1.0
    // C = 1.0 and m = 0.0
    // H is [0.0, 1.0] instea of [0, 360]
    // https://www.rapidtables.com/convert/color/hsv-to-rgb.html
    int region = (int) Math.floor(hue * 6);
    double x = (hue * 6) - Math.floor(hue * 6);

    return switch (region) {
      case 0 -> new LedColor(1.0, x, 0.0);
      case 1 -> new LedColor(x, 1.0, 0.0);
      case 2 -> new LedColor(0.0, 1.0, x);
      case 3 -> new LedColor(0.0, x, 1.0);
      case 4 -> new LedColor(x, 0.0, 1.0);
      case 5 -> new LedColor(1.0, 0.0, x);
      default -> LedColor.off;
    };
  }
  ;
}
