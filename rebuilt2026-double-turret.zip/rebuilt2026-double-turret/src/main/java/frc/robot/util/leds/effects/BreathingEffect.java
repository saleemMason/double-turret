/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import static edu.wpi.first.units.Units.Seconds;

import edu.wpi.first.units.measure.Time;
import edu.wpi.first.wpilibj.Timer;
import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;
import frc.robot.util.math.Range;

public class BreathingEffect implements LedEffect {
  private static final Range normalizedRange = new Range(0.0, 1.0);

  private final LedEffect effect;
  private final Timer timer;
  private final Time breathingInterval;
  private final Range breathingRange;

  private BreathingEffect(
      LedEffect effect, Range breathingRange, Time breathingInterval, Timer timer) {
    this.effect = effect;
    this.breathingInterval = breathingInterval;
    this.breathingRange = breathingRange.clampTo(normalizedRange);

    this.timer = timer;
    this.timer.start();
  }

  public BreathingEffect(LedEffect effect, Range breathingRange, Time breathingInterval) {
    this(effect, breathingRange, breathingInterval, new Timer());
  }

  public BreathingEffect(LedEffect effect, Range breathingRange) {
    this(effect, breathingRange, Seconds.of(4));
  }

  public BreathingEffect(LedEffect effect) {
    this(effect, new Range(0.0, 1.0));
  }

  private static double calculateBreathingState(double normalizedValue) {
    // Original source of equation:
    // https://github.com/ThingPulse/esp32-icon64-a2dp/blob/bc76cc8335dbd26c5fe88c4d54aaa08c04b599fd/src/main.cpp#L198
    // https://www.desmos.com/calculator/4ii9jgwau9
    var a = Math.sin((normalizedValue - 0.25) * 2.0 * Math.PI);
    return (Math.exp(a) - 0.36787944) / 2.3504;
  }

  @Override
  public LedOutputFn process(LedSection section) {
    var value =
        normalizedRange.remap(
            calculateBreathingState(timer.get() / (breathingInterval).in(Seconds)),
            breathingRange,
            false);

    LedOutputFn fn = effect.process(section);
    return (pos) -> fn.get(pos).adjustSaturation(value);
  }
}
