package frc.robot.util.pid;

import com.ctre.phoenix6.configs.Slot0Configs;
import com.ctre.phoenix6.configs.Slot1Configs;
import com.ctre.phoenix6.configs.Slot2Configs;
import com.revrobotics.spark.ClosedLoopSlot;
import com.revrobotics.spark.config.ClosedLoopConfig;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.controller.ProfiledPIDController;
import edu.wpi.first.math.trajectory.TrapezoidProfile;

public class PidConstants {
  protected double kP;
  protected double kD;

  public double getKP() {
    return kP;
  }

  public PidConstants withKP(double kP) {
    this.kP = kP;
    return this;
  }

  public double getKD() {
    return kD;
  }

  public PidConstants withKD(double kD) {
    this.kD = kD;
    return this;
  }

  public Slot0Configs getTalonSlot0() {
    return new Slot0Configs().withKP(kP).withKD(kD);
  }

  public Slot1Configs getTalonSlot1() {
    return new Slot1Configs().withKP(kP).withKD(kD);
  }

  public Slot2Configs getTalonSlot2() {
    return new Slot2Configs().withKP(kP).withKD(kD);
  }

  public ClosedLoopConfig getSparkConfig() {
    return getSparkConfig(ClosedLoopSlot.kSlot0);
  }

  public ClosedLoopConfig getSparkConfig(ClosedLoopSlot slot) {
    ClosedLoopConfig config = new ClosedLoopConfig();
    config.pid(kP, 0.0, kD, slot);

    return config;
  }

  public PIDController getWpilibPidController() {
    return new PIDController(kP, 0.0, kD);
  }

  public ProfiledPIDController getWpilibProfiledPidController(
      TrapezoidProfile.Constraints profile) {
    return new ProfiledPIDController(kP, 0.0, kD, profile);
  }

  public ProfiledPIDController getWpilibProfiledPidController(MotionProfileConstants profile) {
    return new ProfiledPIDController(kP, 0.0, kD, profile.getWpilibTrapezoidProfile());
  }
}
