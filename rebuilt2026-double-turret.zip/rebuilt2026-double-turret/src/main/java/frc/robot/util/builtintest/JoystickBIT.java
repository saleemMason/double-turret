package frc.robot.util.builtintest;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj2.command.button.CommandGenericHID;

/** Built-in-test that fails if a controller is disconnected. */
public class JoystickBIT extends BuiltInTest {
  private final String detail;
  private final int joystickPort;

  public JoystickBIT(String joystickName, Severity severity, CommandGenericHID joystick) {
    super(joystickName + "_disconnected", severity);
    this.detail = joystickName + " controller is disconnected.";
    this.joystickPort = joystick.getHID().getPort();
  }

  @Override
  public TestStatus getStatus() {
    return new TestStatus(DriverStation.isJoystickConnected(joystickPort), detail);
  }
}
