package frc.robot.util.gradientvalley;

import static edu.wpi.first.units.Units.Meters;
import static edu.wpi.first.units.Units.MetersPerSecond;

import edu.wpi.first.units.measure.Distance;
import edu.wpi.first.units.measure.LinearVelocity;
import frc.robot.util.gradientvalley.GradientValley.GradientFunction1d;

public class OneDimensionalGradients {
  public static GradientFunction1d quadraticReciprocal(LinearVelocity k, Distance R) {
    double kMetersPerSec = k.in(MetersPerSecond);
    double RMeters = R.in(Meters);

    double numerator = 16.0 * Math.pow(RMeters, 3.0) * kMetersPerSec;

    double middleCoeff = 6.0 * Math.pow(RMeters, 2.0);
    double constant = 9.0 * Math.pow(RMeters, 4.0);

    return (distance) -> {
      double distanceMeters = distance.in(Meters);
      double velocityMetersPerSec =
          -numerator
              * distanceMeters
              / (Math.pow(distanceMeters, 4.0)
                  + middleCoeff * Math.pow(distanceMeters, 2.0)
                  + constant);
      return MetersPerSecond.of(velocityMetersPerSec);
    };
  }

  public static GradientFunction1d beesFunction(LinearVelocity k, Distance R) {
    double kMetersPerSec = k.in(MetersPerSecond);
    double RMeters = R.in(Meters);

    double coeff = 2.0 * kMetersPerSec / RMeters;

    return (distance) -> {
      double distanceMeters = distance.in(Meters);
      double velocityMetersPerSec =
          -coeff * (1.0 / (1.0 + Math.pow(distanceMeters / RMeters, 2))) * distanceMeters;
      return MetersPerSecond.of(velocityMetersPerSec);
    };
  }
}
