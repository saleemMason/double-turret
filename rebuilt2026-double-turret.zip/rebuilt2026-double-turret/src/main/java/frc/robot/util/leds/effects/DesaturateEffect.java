package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedColor;
import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;

public class DesaturateEffect implements LedEffect {
  private final LedEffect effect;
  private final double saturation;

  /**
   * An effect that adjust's the saturation of another effect. This may be used to apply a final
   * brightness modifier to certain effects or the led run as a whole. A saturation of 0.0 will
   * result in {@link LedColor#black}. A saturation of 1.0 will result in the same exact color.
   *
   * @param effect the {@link LedEffect} to desaturate
   * @param saturation how much to adjust the saturation of the current color [0.0, 1.0]
   * @see LedColor#adjustSaturation(double)
   */
  public DesaturateEffect(LedEffect effect, double saturation) {
    this.effect = effect;
    this.saturation = saturation;
  }

  @Override
  public LedOutputFn process(LedSection section) {
    LedOutputFn fn = effect.process(section);
    return (pos) -> fn.get(pos).adjustSaturation(saturation);
  }
}
