package frc.robot.util.math;

import edu.wpi.first.units.Measure;
import edu.wpi.first.units.Unit;

public class UnitUtil {
  public static <U extends Unit, T extends Measure<U>> T min(T a, T b) {
    return (a.compareTo(b) <= 0) ? a : b;
  }

  public static <U extends Unit, T extends Measure<U>> T max(T a, T b) {
    return (a.compareTo(b) >= 0) ? a : b;
  }

  public static <U extends Unit, T extends Measure<U>> T clamp(T value, T low, T high) {
    return max(low, min(value, high));
  }
}
