/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;
import java.util.function.BooleanSupplier;

/**
 * Given a {@link ConditionalEffect}, this class will change all LEDs under the control of this
 * effect to either be an {@link LedEffect} representing a false state or an {@link LedEffect}
 * representing the true state.
 */
public class ConditionalEffect implements LedEffect {
  private final LedEffect trueEffect;
  private final LedEffect falseEffect;
  private final BooleanSupplier condition;

  /**
   * Creates a {@link ConditionalEffect} with the given false and true effects to display based on
   * what the state of the given {@link ConditionalEffect} is.
   *
   * @param trueEffect the {@link LedEffect} to display when condition is true
   * @param falseEffect the {@link LedEffect} to display when condition is false
   * @param condition the {@link ConditionalEffect} that is used to determine which effect is
   *     displayed at any given moment
   */
  public ConditionalEffect(LedEffect trueEffect, LedEffect falseEffect, BooleanSupplier condition) {
    this.trueEffect = trueEffect;
    this.falseEffect = falseEffect;
    this.condition = condition;
  }

  @Override
  public LedOutputFn process(LedSection section) {
    return condition.getAsBoolean() ? trueEffect.process(section) : falseEffect.process(section);
  }

  /**
   * A new {@link ConditionalEffect} based on the current {@link ConditionalEffect
   * ConditionalEffect}, but with a different {@link ConditionalEffect} to be used to decide the
   * state of the effect.
   *
   * @param condition the new {@link ConditionalEffect} to be used
   * @return a new {@link ConditionalEffect} using the new {@link ConditionalEffect} given
   */
  public ConditionalEffect withcondition(BooleanSupplier condition) {
    return new ConditionalEffect(falseEffect, trueEffect, condition);
  }

  /**
   * A new {@link ConditionalEffect} based on the current {@link ConditionalEffect
   * ConditionalEffect}, but with a different {@link LedEffect} to be used to decide what is
   * displayed when the {@link ConditionalEffect} is true.
   *
   * @param trueEffect the new {@link LedEffect} to be used when the {@link ConditionalEffect} is
   *     true
   * @return a new {@link ConditionalEffect} using the new true {@link LedEffect LedEffect} given
   */
  public ConditionalEffect withTrueEffect(LedEffect trueEffect) {
    return new ConditionalEffect(falseEffect, trueEffect, condition);
  }

  /**
   * A new {@link ConditionalEffect} based on the current {@link ConditionalEffect
   * ConditionalEffect}, but with a different {@link LedEffect} to be used to decide what is
   * displayed when the {@link ConditionalEffect} is false.
   *
   * @param falseEffect the new {@link LedEffect} to be used when the {@link ConditionalEffect} is
   *     false
   * @return a new {@link ConditionalEffect} using the new false {@link LedEffect LedEffect} given
   */
  public ConditionalEffect withFalseEffect(LedEffect falseEffect) {
    return new ConditionalEffect(falseEffect, trueEffect, condition);
  }
}
