/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.robotidentifter;

import edu.wpi.first.wpilibj.DriverStation;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.littletonrobotics.junction.Logger;

/**
 * This class is used to identify which RoboRIO the code is currently being ran on. It accepts
 * anything as the value that gets stored in the internal map, but its recommended to use an enum
 * representing your robots.
 *
 * @param <R> the class used to represent all the robots that are known and what their MAC
 *     address(es) are
 */
public class RobotIdentifier<R extends RobotIdentification> {
  private final RobotIdentifierIO<R> robotIdentifierIO;
  private final RobotIdentifierIOInputsAutoLogged robotIdentifierInputs =
      new RobotIdentifierIOInputsAutoLogged();

  private final Map<String, String> macAddressToNameMap = new HashMap<>();
  private final Map<String, R> identifierNameMap = new HashMap<>();
  private final R defaultRobot;

  /**
   * Creates a {@link RobotIdentification} used to ID the robot that will use all possible enum
   * values. If the MAC address isn't found when {@link determineRobot} is called, the given {@code
   * defaultRobot} is used instead.
   *
   * @param defaultRobot the default robot value that is used if the MAC address doesn't match what
   *     is provided.
   * @return a {@link RobotIdentification} using all enum options
   * @param <E> The enum-based {@link RobotIdentification}
   */
  public static <E extends Enum<E> & RobotIdentification> RobotIdentifier<E> fromEnum(
      RobotIdentifierIO<E> robotIdentifierIO, E defaultRobot) {
    return new RobotIdentifier<E>(
        robotIdentifierIO, defaultRobot, Arrays.asList(getEnumConstants(defaultRobot)));
  }

  /**
   * Creates a RobotIdentifier used to ID the robot. If the MAC address isn't found when {@link
   * determineRobot} is called, the given {@code defaultRobot} is used instead.
   *
   * @param defaultRobot the default robot value that is used if the MAC address doesn't match what
   *     is provided.
   * @param options the list of all possible robot options to search for.
   */
  public RobotIdentifier(RobotIdentifierIO<R> robotIdentifierIO, R defaultRobot, List<R> options) {
    this.robotIdentifierIO = robotIdentifierIO;
    this.defaultRobot = defaultRobot;

    for (R option : options) {
      for (var macAddress : option.getMacAddresses()) {
        if (macAddressToNameMap.containsKey(macAddress)) {
          DriverStation.reportError(
              "Duplicate MAC address \""
                  + macAddress
                  + "\" for RobotIdentifier! Using last specified.",
              false);
        }

        macAddressToNameMap.put(macAddress.toUpperCase(), option.name());
      }

      String identifierName = option.name().toUpperCase();
      if (identifierNameMap.containsKey(identifierName)) {
        DriverStation.reportError(
            "Duplicate name \"" + identifierName + "\" for RobotIdentifier! Using last specified.",
            false);
      }

      identifierNameMap.put(identifierName, option);
    }
  }

  /**
   * Checks all the network interfaces on the device the code is running on, and checks if there are
   * any matches. If there are no matches, the default robot is used. If there are multiple matches,
   * the first one found is used.
   *
   * @return the robot that first matches one of the MAC addresses, or the default robot if none is
   *     found
   */
  public R determineRobot() {
    robotIdentifierIO.updateInputs(robotIdentifierInputs, macAddressToNameMap);
    Logger.processInputs("RobotIdentifier", robotIdentifierInputs);

    String identifierName = robotIdentifierInputs.identifierName;
    if (identifierName == null) {

      return defaultRobot;
    }

    R identifier = identifierNameMap.get(identifierName);
    if (identifier == null) {
      DriverStation.reportError(
          "No RobotIdentification matched name \"" + identifierName + "\" Using default.", false);
      return defaultRobot;
    }

    System.out.println("Robot determined to be: " + identifierName);

    return identifier;
  }

  private static <T extends Enum<T>> T[] getEnumConstants(T sample) {
    @SuppressWarnings("unchecked")
    var c = (Class<T>) sample.getClass();
    return c.getEnumConstants();
  }
}
