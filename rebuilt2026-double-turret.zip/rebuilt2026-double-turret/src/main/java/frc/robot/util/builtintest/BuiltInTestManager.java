// Copyright (c) 2021-2026 Littleton Robotics
// http://github.com/Mechanical-Advantage
//
// Use of this source code is governed by a BSD
// license that can be found in the LICENSE file
// at the root directory of this project.

package frc.robot.util.builtintest;

import edu.wpi.first.wpilibj.Alert;
import edu.wpi.first.wpilibj.DriverStation;
import frc.robot.util.builtintest.BuiltInTest.TestStatus;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Manages objects and packages for annotation logging of outputs with {@link
 * org.littletonrobotics.junction.AutoLogOutput AutoLogOutput}.
 */
public class BuiltInTestManager {
  private class BuiltInTestWithAlert {
    private final BuiltInTest test;
    private final String path;
    private final Alert alert;

    public BuiltInTestWithAlert(BuiltInTest test, String path) {
      this.test = test;
      this.path = path;
      this.alert = new Alert(getText(""), test.getSeverity().toAlertType());
    }

    private String getText(String detail) {
      return path + test.getName() + ": " + (detail.isBlank() ? "failed" : detail);
    }

    public TestStatus update(boolean showAlert) {
      TestStatus status = test.getStatus();
      alert.setText(getText(status.detail()));
      alert.set(showAlert && !status.pass());
      return status;
    }
  }

  private static final Set<String> allowedPackages = new HashSet<>();
  private final List<Integer> scannedObjectHashes = new ArrayList<>();
  private final List<BuiltInTestWithAlert> allTests = new ArrayList<>();

  public BuiltInTestManager() {}

  public void updateTests(boolean showAlerts) {
    for (BuiltInTestWithAlert test : allTests) {
      test.update(showAlerts);
    }
  }

  /**
   * Adds a new allowed package to use when scanning for built-in-tests. By default, the parent
   * class where {@code @AutoLogOutput} is used must be within the same package as {@code Robot} (or
   * a subpackage). Calling this method registers a new allowed package, such as a "lib" package
   * outside of normal robot code.
   *
   * <p>This method must be called within the constructor of {@code Robot}.
   *
   * @param packageName The new allowed package name (e.g. "frc.lib")
   */
  public static void addPackage(String packageName) {
    allowedPackages.add(packageName);
  }

  /** Records values from all registered fields. */
  static void periodic() {}

  /**
   * Registers a root object, scanning for built-in-tests recursively.
   *
   * @param root The object to scan recursively.
   */
  public void addObject(Object root) {
    allowedPackages.add(root.getClass().getPackageName());
    addObjectImpl(root, "/");
  }

  /**
   * Registers a root object, scanning for built-in-tests recursively.
   *
   * @param root The object to scan recursively.
   */
  private void addObjectImpl(Object root, String testPath) {
    // Check if package name is valid
    String packageName = root.getClass().getPackageName();
    boolean packageNameValid = false;
    for (String allowedPackage : allowedPackages) {
      if (packageName.startsWith(allowedPackage)) {
        packageNameValid = true;
        break;
      }
    }
    if (!packageNameValid) return;

    // Check if object has already been scanned
    if (scannedObjectHashes.contains(root.hashCode())) return;
    scannedObjectHashes.add(root.hashCode());

    if (root instanceof BuiltInTestSystem s) {
      testPath += s.getTestSystemName() + "/";
    }

    if (root instanceof BuiltInTest test) {
      allTests.add(new BuiltInTestWithAlert(test, testPath));
    }

    // If array, loop over individual items
    if (root.getClass().isArray()) {
      Object[] rootArray = (Object[]) root;
      for (Object item : rootArray) {
        if (item != null) {
          addObjectImpl(item, testPath);
        }
      }
      return;
    }

    // Loop over declared fields
    for (FieldAndDeclaringClass fieldAndDeclaringClass : getAllFields(root.getClass())) {
      Field field = fieldAndDeclaringClass.field;
      Class<?> declaringClass = fieldAndDeclaringClass.declaringClass;
      if (!field.trySetAccessible()) return;

      boolean isBuiltInTest = field.getClass().isAssignableFrom(BuiltInTest.class);
      if (isBuiltInTest && !Modifier.isFinal(field.getModifiers())) {
        DriverStation.reportError(
            "BuiltInTest field '"
                + declaringClass.getName()
                + "#"
                + field.getName()
                + "' is not final!",
            false);
      }

      Object fieldValue = null;
      try {
        fieldValue = field.get(root);
      } catch (IllegalArgumentException | IllegalAccessException e) {
        if (isBuiltInTest) {
          DriverStation.reportError(
              "Error accessing BuiltInTest field '"
                  + declaringClass.getName()
                  + "#"
                  + field.getName()
                  + "': "
                  + e.getMessage(),
              e.getStackTrace());
        }

        return;
      }

      if (fieldValue == null) {
        if (isBuiltInTest) {
          DriverStation.reportError(
              "BuiltInTest field '"
                  + declaringClass.getName()
                  + "#"
                  + field.getName()
                  + "' is null!",
              false);
        }
        return;
      }

      addObjectImpl(fieldValue, testPath);
    }
  }

  /** Returns the set of all fields in the class and its superclasses (public and private). */
  private static List<FieldAndDeclaringClass> getAllFields(Class<?> type) {
    List<FieldAndDeclaringClass> fields = new ArrayList<>();
    while (type != null && type != Object.class) {
      for (Field field : type.getDeclaredFields()) {
        fields.add(new FieldAndDeclaringClass(field, type));
      }
      type = type.getSuperclass();
    }
    return fields;
  }

  private static class FieldAndDeclaringClass {
    public final Field field;
    public final Class<?> declaringClass;

    public FieldAndDeclaringClass(Field field, Class<?> declaringClass) {
      this.field = field;
      this.declaringClass = declaringClass;
    }
  }
}
