package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;
import java.util.function.Supplier;

public class DeferredEffect implements LedEffect {
  private final Supplier<LedEffect> supplier;

  /**
   * @param supplier The effect supplier
   */
  public DeferredEffect(Supplier<LedEffect> supplier) {
    this.supplier = supplier;
  }

  @Override
  public LedOutputFn process(LedSection section) {
    LedEffect effect = supplier.get();
    return effect.process(section);
  }
}
