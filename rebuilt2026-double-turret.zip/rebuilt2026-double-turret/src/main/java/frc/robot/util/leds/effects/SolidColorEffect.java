/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedColor;
import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedEffect.SimpleLedEffect;

/**
 * Single color effect that sets all LEDs under control by this effect to the same static color
 * provided on construction of this effect.
 */
public class SolidColorEffect implements SimpleLedEffect {
  private final LedColor color;

  /**
   * Creates a {@link SolidColorEffect} that will display the same static color for all LEDs under
   * the control of this effect.
   *
   * @param color the color to set all the LEDs to that are being controlled by this effect
   */
  public SolidColorEffect(LedColor color) {
    this.color = color;
  }

  @Override
  public LedColor get(double position) {
    return color;
  }

  /**
   * Factory for creating an effect that would turn off the LEDs if used.
   *
   * @return an off {@link SolidColorEffect}
   */
  public static LedEffect off() {
    return LedColor.off.asLedEffect();
  }
}
