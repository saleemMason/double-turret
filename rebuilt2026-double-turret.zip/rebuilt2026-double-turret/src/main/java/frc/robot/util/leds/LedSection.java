/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds;

import frc.robot.util.leds.LedEffect.LedOutputFn;
import frc.robot.util.leds.effects.LedSectionEffect;
import frc.robot.util.leds.effects.SolidColorEffect;

/**
 * Represents a single continuous section of LEDs. Can have a single {@link LedEffect} applied to it
 * at any given point in time.
 *
 * @see LedSectionEffect
 */
public class LedSection {
  /** The result of processing an {@link LedSection}. */
  public static class LedIndexFn implements LedOutputFn {
    private final double ledPositionDenominator;
    private final LedOutputFn fn;

    LedIndexFn(LedOutputFn fn, int ledCount) {
      this.fn = fn;
      this.ledPositionDenominator = ledCount - 1;
    }

    @Override
    public LedColor get(double position) {
      return fn.get(position);
    }

    /**
     * Converts physical a LED index from the start of the {@link LedSection} into the {@link
     * LedColor} the effect should produce at that index.
     *
     * @param index The physical LED index from the start of the {@link LedSection}
     * @return The color the effect produces at the provided index
     */
    public LedColor getIndex(int index) {
      return get(index / ledPositionDenominator);
    }
  }

  private final LedEffect effect;
  private final int ledCount;
  private final boolean reversed;

  /**
   * Creates a {@link LedSection} with the specified number of LEDs.
   *
   * @param effect the {@link LedEffect} to display
   * @param ledCount the LED count in the given {@link LedSection}
   * @param reversed whether to reverse the direction of the displayed effect
   */
  public LedSection(LedEffect effect, int ledCount, boolean reversed) {
    this.effect = reversed ? effect.reversed() : effect;
    this.ledCount = ledCount;
    this.reversed = reversed;
  }

  /**
   * Creates a {@link LedSection} with the specified number of LEDs.
   *
   * @param effect the {@link LedEffect} to display
   * @param ledCount the LED count in the given {@link LedSection}
   */
  public LedSection(LedEffect effect, int ledCount) {
    this(effect, ledCount, false);
  }

  /**
   * Creates a {@link LedSection} with the specified number of LEDs.
   *
   * @param ledCount the LED count in the given {@link LedSection}
   * @param reversed whether to reverse the direction of the displayed effect
   */
  public LedSection(int ledCount, boolean reversed) {
    this(SolidColorEffect.off(), ledCount, false);
  }

  /**
   * Creates a {@link LedSection} with the specified number of LEDs.
   *
   * @param ledCount the LED count in the given {@link LedSection}
   */
  public LedSection(int ledCount) {
    this(ledCount, false);
  }

  /**
   * How many LEDs are in this {@link LedSection}.
   *
   * @return how many LEDs are in this {@link LedSection}
   */
  public int getLedCount() {
    return ledCount;
  }

  /**
   * Process the {@index LedEffects} applied to this section and return a helper function to get the
   * LED color by index.
   */
  public LedIndexFn process() {
    return new LedIndexFn(effect.process(this), ledCount);
  }

  /**
   * Create a new {@link LedSection} with the ledCount and reversed values of this one, and a
   * different effect. Useul when specifying the LED strip topology as constants seperate from it's
   * animations.
   *
   * @param effect The effect to apply to the new {@link LedSection}
   * @return The new {@link LedSection}
   */
  public LedSection withEffect(LedEffect effect) {
    return new LedSection(effect, this.ledCount, this.reversed);
  }
}
