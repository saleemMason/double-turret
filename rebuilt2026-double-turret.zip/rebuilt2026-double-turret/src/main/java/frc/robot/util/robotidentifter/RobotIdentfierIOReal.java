package frc.robot.util.robotidentifter;

import edu.wpi.first.wpilibj.DriverStation;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Map;

public class RobotIdentfierIOReal<R extends RobotIdentification> implements RobotIdentifierIO<R> {
  @Override
  public void updateInputs(
      RobotIdentifierIOInputs inputs, Map<String, String> macAddressToNameMap) {
    String macAddress = getMacAddress();

    if (macAddress == null) {
      DriverStation.reportError("Could not determine MAC address! Using default.", false);
      inputs.identifierName = null;
    }

    String identifierName = macAddressToNameMap.get(macAddress);
    if (identifierName == null) {
      DriverStation.reportError(
          "No RobotIdentification matched MAC address \"" + macAddress + "\" Using default.",
          false);
      inputs.identifierName = null;
    }

    inputs.identifierName = identifierName;
  }

  private static String getMacAddress() {
    try {
      Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
      while (networkInterfaces.hasMoreElements()) {
        NetworkInterface ni = networkInterfaces.nextElement();
        byte[] hardwareAddress = ni.getHardwareAddress();

        if (hardwareAddress != null) {
          String[] hexadecimalFormat = new String[hardwareAddress.length];

          for (int i = 0; i < hardwareAddress.length; i++) {
            hexadecimalFormat[i] = String.format("%02X", hardwareAddress[i]);
          }

          var address = String.join("-", hexadecimalFormat).toUpperCase();
          System.out.println("Found MAC Address: " + address);
          return address;
        }
      }
    } catch (SocketException e) {
      DriverStation.reportError("Error determining MAC Addresses", true);
    }

    return null;
  }
}
