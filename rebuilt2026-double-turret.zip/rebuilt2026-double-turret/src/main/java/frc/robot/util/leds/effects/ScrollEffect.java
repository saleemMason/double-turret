/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import static edu.wpi.first.units.Units.Seconds;

import edu.wpi.first.units.measure.Frequency;
import edu.wpi.first.units.measure.Time;
import edu.wpi.first.wpilibj.Timer;
import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;

/** A scrolling solid color bar effect. */
public class ScrollEffect implements LedEffect {
  /** Various scrolling LED styles that can be used. */
  public enum Style {
    /**
     * Scrolls a solid color bar starting from the beginning of the {@link
     * frc.robot.util.leds.LedSection}, and continuing forwards towards the end of the {@link
     * frc.robot.util.leds.LedSection}, before resetting back to the beginning again.
     */
    INCREASING,
    /**
     * Scrolls a solid color bar starting from the end of the {@link
     * frc.robot.util.leds.LedSection}, and continuing backwards towards the beginning of the {@link
     * frc.robot.util.leds.LedSection}, before resetting back to the end again.
     */
    DECREASING,
    /**
     * Scrolls two a solid color bars from both sides of the {@link frc.robot.util.leds.LedSection},
     * in towards the center of the {@link frc.robot.util.leds.LedSection}, before resetting back to
     * the outer edges again.
     */
    TOWARDS_CENTER,
    /**
     * Scrolls two a solid color bars from the center of {@link frc.robot.util.leds.LedSection}, out
     * towards the outer edges of the {@link frc.robot.util.leds.LedSection}, before resetting back
     * to the center again.
     */
    AWAY_FROM_CENTER
  }

  private final Timer timer;
  private final Time scrollInterval;
  private final Style scrollStyle;

  private final LedEffect backgroundEffect;
  private final LedEffect scrollEffect;

  /**
   * Creates a {@link ScrollEffect} with the given colors, scrolling style and repeating interval.
   *
   * @param backgroundEffect the color of the background
   * @param scrollEffect the color of LED(s) that scroll past the background
   * @param style the style of scrolling
   * @param scrollInterval the time it takes to complete one full cycle of the scrolling animation
   *     before it loops
   * @param timer the timer used to time the scrolling animation
   */
  private ScrollEffect(
      LedEffect backgroundEffect,
      LedEffect scrollEffect,
      Style style,
      Time scrollInterval,
      Timer timer) {
    this.backgroundEffect = backgroundEffect;
    this.scrollEffect = scrollEffect;

    this.timer = timer;
    this.scrollInterval = scrollInterval;
    scrollStyle = style;

    this.timer.start();
  }

  /**
   * Creates a {@link ScrollEffect} with the given colors, scrolling style and repeating interval.
   *
   * @param backgroundEffect the color of the background
   * @param scrollEffect the color of LED(s) that scroll past the background
   * @param style the style of scrolling
   * @param scrollInterval the time it takes to complete one full cycle of the scrolling animation
   *     before it loops
   */
  public ScrollEffect(
      LedEffect backgroundEffect, LedEffect scrollEffect, Style style, Time scrollInterval) {
    this(backgroundEffect, scrollEffect, style, scrollInterval, new Timer());
  }

  /**
   * Creates a {@link ScrollEffect} with the given colors, scrolling style and repeating frequency.
   *
   * @param backgroundEffect the color of the background
   * @param scrollEffect the color of LED(s) that scroll past the background
   * @param style the style of scrolling
   * @param scrollFrequency the frequency of the scrolling animation, or how many times it will loop
   *     per second
   */
  public ScrollEffect(
      LedEffect backgroundEffect, LedEffect scrollEffect, Style style, Frequency scrollFrequency) {
    this(backgroundEffect, scrollEffect, style, scrollFrequency.asPeriod());
  }

  private double getScrollPosition() {
    double scrollPos = timer.get() / scrollInterval.in(Seconds);
    if (timer.hasElapsed(scrollInterval)) {
      timer.reset();
    }

    if (scrollStyle == Style.DECREASING || scrollStyle == Style.AWAY_FROM_CENTER) {
      scrollPos = 1.0 - scrollPos;
    }

    return scrollPos;
  }

  private boolean showScrollEffect(double position, double scrollPosition) {
    if (scrollStyle == Style.TOWARDS_CENTER || scrollStyle == Style.AWAY_FROM_CENTER) {
      return (position <= (scrollPosition / 2.0) || (1.0 - position) <= (scrollPosition / 2.0));

    } else {
      return (position <= scrollPosition);
    }
  }

  @Override
  public LedOutputFn process(LedSection section) {
    LedOutputFn backgroundFn = backgroundEffect.process(section);
    LedOutputFn scrollFn = scrollEffect.process(section);

    double scrollPos = getScrollPosition();
    return (pos) -> showScrollEffect(pos, scrollPos) ? scrollFn.get(pos) : backgroundFn.get(pos);
  }

  public ScrollEffect withBackgroundEffect(LedEffect effect) {
    return new ScrollEffect(effect, scrollEffect, scrollStyle, scrollInterval);
  }

  public ScrollEffect withScrollEffect(LedEffect effect) {
    return new ScrollEffect(backgroundEffect, effect, scrollStyle, scrollInterval);
  }

  public ScrollEffect withStyle(Style style) {
    return new ScrollEffect(backgroundEffect, scrollEffect, style, scrollInterval);
  }
}
