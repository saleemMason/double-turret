package frc.robot.util.builtintest;

/** Built-in-test that fails if a "device" is disconnected. */
public class DisconnectedBIT extends BuiltInTest {
  private final String detail;
  private boolean isConnected = false;

  /**
   * Creates a new DisconnectedBIT
   *
   * @param deviceName Name of the potentially disconnected device.
   * @param severity Test urgency level.
   * @param detail Additional details on what caused the test to fail.
   */
  public DisconnectedBIT(String deviceName, Severity severity, String detail) {
    super(deviceName + "_disconnected", severity);
    this.detail = detail;
  }

  /**
   * Creates a new DisconnectedBIT
   *
   * @param deviceName Name of the potentially disconnected device.
   * @param severity Test urgency level.
   */
  public DisconnectedBIT(String deviceName, Severity severity) {
    this(deviceName, severity, deviceName + "is disconnected.");
  }

  public void setConnected(boolean connected) {
    this.isConnected = connected;
  }

  @Override
  public TestStatus getStatus() {
    return new TestStatus(isConnected, detail);
  }
}
