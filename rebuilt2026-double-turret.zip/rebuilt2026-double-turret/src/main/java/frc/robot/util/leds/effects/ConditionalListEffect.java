/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedColor;
import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;
import java.util.List;
import java.util.function.BooleanSupplier;

/**
 * Similar to a {@link ConditionalEffect}, but uses a list of conditions to decide which effect to
 * show. If multiple conditions are true, then a priority order is used to decide which effect to
 * use out of the set of true conditions.
 */
public class ConditionalListEffect implements LedEffect {
  /** A single entry to be used in a {@link ConditionalEffect}. */
  public static class Entry {
    /** The {@link LedEffect} to use if the {@code condition} is true. */
    public final LedEffect effect;
    /** The condition that decides if the {@link LedEffect} should be used. */
    public final BooleanSupplier condition;

    /**
     * Creates a single entry to be used in a {@link ConditionalEffect}.
     *
     * @param effect the {@link LedEffect} to use
     * @param condition the condition that decides if the {@link LedEffect} should be used
     */
    public Entry(LedEffect effect, BooleanSupplier condition) {
      this.effect = effect;
      this.condition = condition;
    }
  }

  private final LedEffect defaultEffect;
  private final List<Entry> entries;

  /**
   * Creates a {@link ConditionalListEffect} with the given list of {@link LedEffect}/{@link
   * BooleanSupplier} pairs, and a default {@link LedEffect} that will be used as fallback effect in
   * case none of the conditions are true. The list of entries should be provided in a priority
   * order, where the first entry in the list is the highest priority if there are more then one
   * true conditions detected.
   *
   * @param defaultEffect the default effect to fallback to if non of the provided entries have a
   *     true condition at a given moment in time
   * @param entries all of the {@link LedEffect}/{@link BooleanSupplier} pairs in a priority list
   *     order where the first entry in the list is the highest priority
   */
  public ConditionalListEffect(LedEffect defaultEffect, Entry... entries) {
    if (entries.length == 0) {
      System.err.println(
          "ConditionalListEffect's entry list is empty. User should just use the default effect directly instead.");
    } else if (entries.length == 1) {
      System.err.println(
          "ConditionalListEffect's entry list consists of a single entry. User should just use a ConditionalEffect instead.");
    }

    this.defaultEffect = defaultEffect;
    this.entries = List.of(entries);
  }

  /**
   * Creates a {@link ConditionalListEffect} with the given list of {@link LedEffect}/{@link
   * BooleanSupplier} pairs. The list of entries should be provided in a priority order, where the
   * first entry in the list is the highest priority if there are more then one true conditions
   * detected. If none of the entries are true, this effect will default to turning the LEDs off.
   *
   * @param entries all of the {@link LedEffect}/{@link BooleanSupplier} pairs in a priority list
   *     order where the first entry in the list is the highest priority
   */
  public ConditionalListEffect(Entry... entries) {
    this(LedColor.off.asLedEffect(), entries);
  }

  @Override
  public LedOutputFn process(LedSection section) {
    for (var entry : entries) {
      if (entry.condition.getAsBoolean()) {
        return entry.effect.process(section);
      }
    }

    return defaultEffect.process(section);
  }
}
